package com.login.application.validation;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.login.application.beans.Customer;

public class CustomerValidation implements Validator {

	public boolean supports(Class<?> argo) {

		return Customer.class.equals(argo);
	}

	@Override
	public void validate(Object arg0, Errors arg1) {

	}
}