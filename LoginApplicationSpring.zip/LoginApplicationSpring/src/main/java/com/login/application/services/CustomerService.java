package com.login.application.services;

import com.login.application.beans.Customer;

public interface CustomerService {

	public void saveCustomer(Customer customer);

	public Customer loginCustomer(Customer customer);

}
