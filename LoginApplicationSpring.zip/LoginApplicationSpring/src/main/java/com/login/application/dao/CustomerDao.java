package com.login.application.dao;

import com.login.application.beans.Customer;

public interface CustomerDao {
	
	public void saveCustomer(Customer customer);
	public Customer loginCustomer(Customer customer);

}